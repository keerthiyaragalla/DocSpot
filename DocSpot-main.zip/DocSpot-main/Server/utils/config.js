module.exports = {
  jwtSecret: "yourSecretKey",
  jwtExpiration: "7d", // Token expiration time (e.g., "1h" for 1 hour)
};
